# third-proto
third try at a prototype for a masters incommunication @DeCA, Aveiro.

TODO:

Registo/Login:
    Introduzir dados de identificação:
    Definir opções de visualização:
        des)ligar sugestões
            Escolher preferências de conteúdos
            Des)ligar opção zapping
        des)ligar lembretes
            Agendamento de lembretes
            Disponibilidade em intervalo pré-definido
            Disponibilidade por acesso a agenda pessoal
            Disponibilidade por proximidade à televisão
        des)ligar radar social
            Associação de outras pessoas
            Por contactos Google
            Por contactos Facebook
Consultar sugestões/agendamentos
